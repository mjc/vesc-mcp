# Embedding model bake-off

- Suite: vescm-165-v2-full-corpus
- Corpus digest: sha256:45e55039cc4bd6b3a74edbc605864facfbdb90b9d088cf0c1af7bde560ea632a
- Corpus: 2869 documents / 13720 chunks

| Candidate | Quantization | Provider p50 (s) | Chunks/s | Fused R@5 | Fused R@10 | Fused MRR@10 | Semantic R@5 | Peak RSS (MiB) |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| lexical control | — | — | — | 0.0400 | 0.0600 | 0.0450 | — | — |
| bge-small-en-v1.5-quantized | quantized | 432.740 | 31.70 | 0.1800 | 0.2400 | 0.1140 | 0.2000 | — |
